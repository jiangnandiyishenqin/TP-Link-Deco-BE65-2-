## SECTION 1 – Reporter Information

Reporter Name / Handle:
Lumina

Email Address:
1547800591@qq.com

## SECTION 2 – Vulnerability Overview

Vulnerability Name:
Deco BE65 V3 Authenticated VLAN ID and Speed Test Type OS Command Injection

Brief Description:
Two independently reachable Web management functions construct shell commands using request-controlled strings without adequate validation or argument separation:

1. The VLAN configuration path concatenates `vlan.id` into a command executed through `luci.sys.fork_exec()`. Numeric conversion and range checks occur only after command execution.
2. The speed-test path concatenates `type` into a command executed through `luci.sys.fork_call()` and `/bin/sh -c`. The code does not restrict this field to the expected `single` or `multiple` values.

An attacker with valid Web management credentials or an authenticated management session can execute arbitrary shell commands with the privileges of the Web backend. No authentication bypass is claimed or required by these findings.

Affected Product(s) / Module / Component:
- TP-Link Deco BE65 Web management service: `uhttpd` and LuCI.
- VLAN: `/admin/network?form=vlan&operation=write`, implemented by `luci.controller.admin.network` and `luci.model.app_network`.
- Speed test: `/admin/device?form=speedtest&operation=write`, implemented by `luci.controller.admin.device` and `luci.model.speed_test`.
- CWE-78: Improper Neutralization of Special Elements Used in an OS Command.

Firmware Version:
1.0.11 Build 260922 (`26092212-rel18351`)

Original Firmware Filename:
`BE65V2_BE65V3_multi_v2_SP1_V2_RSA2048-up-ver1-0-11-P1[26092212-rel18351]_2026-09-21_23.07.02.bin`

Original Firmware SHA-256:
`1c380a5f7c5221b637c801c2de1486d2c8ec1579bb1fa02fbc413ec2ab1c8085`

Decrypted Firmware SHA-256:
`492dbdce705ec4eb1b1f46323eb326a9f05a95d051997a7f7305032e97ae4c1a`

Hardware Version:
V3. The image name indicates a combined BE65 V2/V3 image; this assessment targets V3.

Tested Device Country Code:
Undetermined. The multi-region firmware was analyzed without a physical device carrying a specific regional configuration.

![image-20261106112722477](Deco_BE65_V3_Web_Command_Injection_Report_EN.assets/image-20261106112722477.png)

## SECTION 3 – Discovery Context

Date Discovered:
2026-11-05

Environment (LAN/WAN/App/etc.):
Web management over LAN in an isolated local emulation environment. The report does not establish that these interfaces are exposed on WAN.

Devices Used:
- Windows analysis host running the PoC and HTTP client.
- Ubuntu IoT analysis VM at `192.168.135.137`.
- Unpacked BE65 firmware executed using AArch64 QEMU user-mode emulation and bubblewrap.
- The firmware's `uhttpd` front end and LuCI/CGI back end ran together during validation.
- No physical Deco BE65 was used.

Tools Used:
IDA Pro / Hex-Rays, binwalk, UBI Reader, unsquashfs, tp-link-decrypt, unluac, QEMU, bubblewrap, Python 3, curl, and standard shell utilities.

Additional Context:
Both issues require a valid administrative Web session. The test account password `admin` was deliberately configured in the local fixture.

Evidence level: VALIDATED in QEMU user-mode emulation, including a real login, signed HTTP requests, command side effects, and HTTP retrieval of unique marker files. 

The original vulnerable functions and authentication checks were not patched. To compensate for incomplete emulation startup state, the environment loaded the firmware profile, created a known test account and synthetic device ID, added the emulator user's group mapping, initialized the firmware's existing `luci.dispatcher.call` helper, used LuCI's built-in plain-Lua indexer, normalized the `stok` URL token into its expected dispatcher field, and allowed the firmware's existing ARP-table fallback when the unavailable ubus ARP provider failed. These compatibility measures did not bypass password verification, session/token verification, or request-signature verification.

## SECTION 4 – Technical Details

### Finding A: Authenticated VLAN ID Command Injection

Reproduction Steps:
1. Start the firmware Web front end and LuCI back end in the prepared local emulation environment.
2. Run `python3 poc_vlan_web.py http://192.168.135.137:8080` using the known test-account password.
3. The script obtains the RSA key and sequence number, performs a normal login, retains both the URL `stok` and the `sysauth` cookie, and sends a correctly signed VLAN request.
4. The request's `params.vlan.id` is `1;echo VLAN_OK>/www/<unique-marker>;#`.
5. The model raises a numeric-conversion exception after executing the command. The script then retrieves the unique marker over HTTP and verifies `VLAN_OK`.

Observed result from the final regression:

```text
POST login/login: HTTP 200 ... "stok" returned ...
POST vlan/write: HTTP 500 ... attempt to compare nil with number ...
GET vlan_562b0d3d61b0: HTTP 200 body='VLAN_OK'
VALIDATED: authenticated VLAN id command injection wrote /www/vlan_562b0d3d61b0
```

Proof of Concept (PoC):
The attached `poc_vlan_web.py` implements the complete login, RSA/AES request handling, random marker generation, and result verification. It requires Python's `cryptography` package.

The logical request is:

```http
POST /cgi-bin/luci/;stok=<session-token>/admin/network?form=vlan&operation=write
Cookie: sysauth=<session-cookie>
Content-Type: application/json

{"operation":"write","params":{"vlan":{"enable":true,"id":"1;echo VLAN_OK>/www/<unique-marker>;#"}}}
```

The actual implementation wraps the request parameters in the firmware's required signed/encrypted body. Placeholders above intentionally omit real session data.

![image-20261106112818156](Deco_BE65_V3_Web_Command_Injection_Report_EN.assets/image-20261106112818156.png)

Source-to-sink chain:
1. `/admin` inherits `sysauth=true`; a valid session and token are required.
2. `luci.controller.admin.network` dispatches `form=vlan`, `operation=write` and copies the supplied `vlan.id` into the model argument without a character whitelist.
3. In the tested profile, `profile.switch.ext_switch='yes'`, `switch_vlan='yes'`, and `switch_chip='qca_8386'`; the relevant model path is enabled.
4. The helper beginning at decompiled `app_network.lua:8416` constructs `echo ` .. `A0_2.id` .. ` > /proc/wandetect/isp_vid` at lines 8467-8470.
5. It invokes `luci.sys.fork_exec()` with that string at lines 8471-8474.
6. Only afterward do lines 8476-8484 call `tonumber()` and perform range checks. These later checks cannot prevent the already-executed shell command.

Expected Behavior:
The service must reject nonnumeric VLAN IDs before any state-changing operation or shell invocation. Ideally, it should use a direct file API or fixed argument array instead of a shell.

Actual Behavior:
The request-controlled ID changes shell syntax and executes an additional command. The HTTP 500 response is a post-command exception and is not evidence of failure to exploit.

Potential Exploitation Scenarios:
An attacker who has obtained administrative credentials or a valid management session can execute commands with the Web backend's privileges. The demonstrated impact is local command execution; root-level execution on a physical device was not established.

### Finding B: Authenticated Speed Test Type Command Injection

Reproduction Steps:
1. Use the same authenticated Web environment and a known administrative test account.
2. Run `python3 poc_speedtest_web.py http://192.168.135.137:8080`.
3. The script logs in normally and submits `form=speedtest`, `operation=write` to `/admin/device` with `type` set to `single;echo SPEED_OK>/www/<unique-marker>;exit 0;#` and `is_auto=true`.
4. The `exit 0` fragment prevents the actual speed-test binary from running, so the test produces no external speed-test traffic.
5. The PoC polls for the unique marker because the model's process hierarchy can make the marker appear after the parent request returns.

Observed result:

```text
POST login/login: HTTP 200 ... "stok" returned ...
POST speedtest/write: HTTP 200 {"error_code":0}
GET speed_22178228ffb3: HTTP 200 body='SPEED_OK'
VALIDATED: authenticated speedtest type command injection wrote /www/speed_22178228ffb3
```

Proof of Concept (PoC):
The attached `poc_speedtest_web.py` reuses the tested login and signing helpers from `poc_vlan_web.py`.

The logical request is:

```http
POST /cgi-bin/luci/;stok=<session-token>/admin/device?form=speedtest&operation=write
Cookie: sysauth=<session-cookie>
Content-Type: application/json

{"operation":"write","params":{"type":"single;echo SPEED_OK>/www/<unique-marker>;exit 0;#","is_auto":true}}
```

![image-20261106112846955](Deco_BE65_V3_Web_Command_Injection_Report_EN.assets/image-20261106112846955.png)

Source-to-sink chain:

1. `luci.controller.admin.device` maps `speedtest.write` to the speed-test start handler and passes request parameters to `SPEED_TEST_INST:start_spt()`.
2. `speed_test.lua:205-210` assigns `args.type` to `test_type`; it does not enforce the expected `single`/`multiple` enumeration.
3. With `is_auto=true`, lines 242-246 construct `cmd = SCRIPT_SPEED_TEST .. " " .. test_type`, where `SCRIPT_SPEED_TEST` is `/etc/speed-test/speed_test.sh`.
4. Line 254 passes the resulting string to `luci.sys.fork_call()`.
5. `luci.sys.fork_call()` uses `/bin/sh -c` to execute the constructed command. The shell metacharacters in `type` therefore alter command structure.
6. The separate numeric validation of `select_server_id` does not sanitize `type` and does not prevent this path.

Expected Behavior:
The service should accept only documented test types, pass arguments without invoking a shell, and validate all server selections against known numeric IDs.

Actual Behavior:
An authenticated request can append shell commands to the speed-test invocation. Marker creation was reproduced through the actual Web endpoint, including after the response parser was corrected to handle asynchronous marker creation.

Potential Exploitation Scenarios:
As with Finding A, exploitation requires Web administrative authorization. The issue can provide arbitrary command execution under the Web backend account. No unauthenticated exploit or physical-device privilege level is claimed.

## SECTION 5 – Suggested Fix

Recommended Fix or Mitigation:
1. Remove shell concatenation from both paths. Use direct file APIs or process-execution functions with fixed argument arrays.
2. Validate VLAN IDs as a string of decimal digits, reject failed numeric conversion, and enforce the allowed range before any side effect. Move all validation ahead of command execution.
3. Restrict speed-test `type` to an explicit allowlist (`single` or `multiple`). Validate every selected server ID and never concatenate list entries into a shell command.
4. Preserve the existing authentication, session-token, and request-integrity checks as defense in depth, but do not rely on them as substitutes for input validation.
5. Add regression tests containing `;`, `$()`, quotes, whitespace, and malformed numeric values, and verify that no command or file side effect occurs.
6. Reproduce both fixes on physical V2/V3 hardware and verify behavior under the production Web service account and firewall configuration.

## SECTION 6 – Attachments

Linked Files:
1. `poc_vlan_web.py` — authenticated VLAN PoC and shared Web login/signing helpers.
2. `poc_speedtest_web.py` — authenticated speed-test PoC with asynchronous marker verification.
